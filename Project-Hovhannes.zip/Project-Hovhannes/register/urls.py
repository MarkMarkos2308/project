from . import views
from django.urls import path

# urlpatterns = [
#     path('about/', views.home, name='register-home')
# ]





















